$(document).ready(function(){
	// fifth section script with styles changing
	// get styleProperties before changing
		var styleProp1 = $('div.price_item').children('p:eq(1)').css(['color','backgroundColor','borderColor']);
		var styleProp2 = $('div.price_item').children('p:eq(2)').css(['color','backgroundColor','borderColor']);
	// set hover:function and css-styles of texts
	$('div.price_item button').on('mouseover', function(){
		var parDiv = $(this).parent().parent();
		parDiv.children('p:eq(0)').css('color','#008ed6');
		
		parDiv.children('p:eq(1)').css({color:'white',
										backgroundColor: '#008ed6',
										borderColor: '#008ed6'});
		parDiv.children('p:eq(2)').css({color:'white',
										backgroundColor: '#008ed6',
										borderColor: '#008ed6'});
	});
	// set previous styles
	$('div.price_item button').on('mouseleave', function(){
		var parDiv = $(this).parent().parent();
		parDiv.children('p:eq(0)').css('color','#1a1a1a');
		parDiv.children('p:eq(1)').css(styleProp1);
		parDiv.children('p:eq(2)').css(styleProp2);
	});

});
	